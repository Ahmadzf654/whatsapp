import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  static const String id = 'home_screen';
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'WhatsApp',
            style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
          ),
          bottom: const TabBar(
            tabs: [
              Tab(
                child: Icon(Icons.camera_alt_outlined),
              ),
              Tab(child: Text('Chats')),
              Tab(child: Text('Status')),
              Tab(child: Text('Calls')),
            ],
          ),
          actions: [
            const Icon(Icons.search),
            const SizedBox(
              width: 10,
            ),
            PopupMenuButton(
              icon: const Icon(Icons.more_horiz_outlined),
              itemBuilder: (context) => [
                const PopupMenuItem(value: '1', child: Text('New Group')),
                const PopupMenuItem(value: '2', child: Text('Settings')),
                const PopupMenuItem(value: '3', child: Text('Logout')),
              ],
            ),
            const SizedBox(
              width: 10,
            ),
          ],
        ),
        body: TabBarView(
          children: [
            const Text('Camera'),
            ListView.builder(
              itemCount: 100,
              itemBuilder: (context, index) {
                return const ListTile(
                  leading: CircleAvatar(
                    backgroundImage: AssetImage('assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
                  ),
                  title: Text(
                    'John Wick',
                    style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
                  ),
                  subtitle: Text(
                    'Loving Husband',
                    style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
                  ),
                  trailing: Text(
                    '3:34 pm',
                    style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
                  ),
                );
              },
            ),
            Center(
              child: Stack(
                children: [
                  const CircleAvatar(
                    backgroundImage: AssetImage('assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
                    radius: 50,
                  ),
                  Positioned(
                    bottom: 0,
                    right: 0,
                    child: Container(
                      padding: const EdgeInsets.all(5),
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.blue,
                      ),
                      child: const Icon(
                        Icons.add,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const ListTile(
              leading: CircleAvatar(
                backgroundImage: AssetImage('assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
              ),
            ),
            ListView.builder(
              itemCount: 100,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: const CircleAvatar(
                    backgroundImage: AssetImage('assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
                  ),
                  title: const Text(
                    'John Wick',
                    style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
                  ),
                  subtitle: Text(
                    index.isEven
                        ? 'You missed audio call'
                        : 'You missed video call',
                    style: const TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
                  ),
                  trailing: Icon(index.isEven ? Icons.call : Icons.video_call),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';
// class HomeScreen extends StatefulWidget {
//   static const String id = 'home_screen';
//   const HomeScreen({super.key});
//
//   @override
//   State<HomeScreen> createState() => _HomeScreenState();
// }
//
// class _HomeScreenState extends State<HomeScreen> {
//   @override
//   Widget build(BuildContext context) {
//     return DefaultTabController(
//         length: 4,
//         child: Scaffold(
//           appBar: AppBar(
//             title: const Text(
//               'WhatsApp',
//               style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
//             ),
//             bottom: const TabBar(tabs: [
//               Tab(
//                 child: Icon(Icons.camera_alt_outlined),
//               ),
//               Tab(child: Text('Chats')),
//               Tab(child: Text('Status')),
//               Tab(child: Text('Calls')),
//             ]),
//             actions: [
//               const Icon(Icons.search),
//               const SizedBox(
//                 width: 10,
//               ),
//               PopupMenuButton(
//                   icon: const Icon(Icons.more_horiz_outlined),
//                   itemBuilder: (
//                     context,
//                   ) =>
//                       [
//                         const PopupMenuItem(
//                             value: '1', child: Text('New Group')),
//                         const PopupMenuItem(
//                             value: '2', child: Text('Settings')),
//                         const PopupMenuItem(value: '3', child: Text('Logout'))
//                       ]),
//               const SizedBox(
//                 width: 10,
//               ),
//             ],
//           ),
//           body: TabBarView(
//             children: [
//               const Text('Camera'),
//               ListView.builder(
//                   itemCount: 100,
//                   itemBuilder: (context, index) {
//                     return const ListTile(
//                       leading: CircleAvatar(
//                         backgroundImage: AssetImage(
//                             'assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
//                       ),
//                       title: Text(
//                         'John Wick',
//                         style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
//                       ),
//                       subtitle: Text(
//                         'Loving Husband',
//                         style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
//                       ),
//                       trailing: Text(
//                         '3:34 pm',
//                         style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
//                       ),
//
//                     );
//                   }
//                   ),
//               Stack(
//                 children: [
//                   CircleAvatar(
//                     backgroundImage: AssetImage('assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
//                     radius: 50,
//                   ),
//                   Positioned(bottom: 0,
//                       right: 0,
//                       child: Container(
//                         padding: EdgeInsets.all(5),
//                         decoration: BoxDecoration(
//                           shape: BoxShape.circle,
//                           color: Colors.blue,
//                         ),
//                         child: Icon(
//                           Icons.add,
//                           color: Colors.white,
//                           size: 30,
//                         ),
//                       ))
//
//                 ],
//
//               ),
//               const ListTile(
//
//                 leading:
//                   CircleAvatar(
//                     backgroundImage: AssetImage('assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
//                   ),
//
//               );
//
//               ),
//               ListView.builder(
//                   itemCount: 100,
//                   itemBuilder: (context, index) {
//                     return ListTile(
//                       leading: const CircleAvatar(
//                         backgroundImage: AssetImage(
//                             'assets/WhatsApp Image 2023-07-18 at 11.07.22 AM.jpeg'),
//                       ),
//                       title: const Text(
//                         'John Wick',
//                         style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
//                       ),
//                       subtitle: Text(
//                         index / 2 == 0
//                             ? 'You missed audio call'
//                             : 'You missed video call',
//                         style: const TextStyle(fontFamily: 'IMFellFrenchCanonSC'),
//                       ),
//                       trailing:
//                           Icon(index / 2 == 0 ? Icons.call : Icons.video_call),
//                       // Text('3:34 pm',style: TextStyle(fontFamily: 'IMFellFrenchCanonSC'),),
//                     );
//                   }
//                   ),
//             ],
//           ),
//         );
//
//   }
// }
